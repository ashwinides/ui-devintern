     
            let signUpbtn = document.getElementById("signupbtn");
            let signInbtn = document.getElementById("signinbtn");
            let nameField = document.getElementById("namefield");
            let Title = document.getElementById("title");
            let Name = document.getElementById("name");

            function SignIn(){
                namefield.style.maxHeight = "0" ; 
                title.innerHTML="Sign In"; //it will change the title
                signupbtn.classList.add("disable");//change btn color
                signinbtn.classList.remove("disable");
            

            }

            function SignUp(){
                namefield.style.maxHeight = "60px" ; 
                title.innerHTML="Sign Up"; //it will change the title
                signupbtn.classList.remove("disable");
                signinbtn.classList.add("disable");//change btn color
            }

            // form validation

            function Validation(){
                let Name = document.getElementById("uname").value;
                let Email = document.getElementById("uemail").value;
                let Password = document.getElementById("upass").value;
                let ConformPass = document.getElementById("ucpass").value;


                if(Name == ""){
                    document.getElementById("name").innerHTML="Please Enter Your Name";
                    return false;
                }
                if(((Name.length<=2) || (Name.length>=25))){
                    document.getElementById("name").innerHTML="Please Enter Full Name and number are not allowed";
                    return false;
                }
                if(!isNaN(Name)){
                    document.getElementById("name").innerHTML="number are not allowed";
                    return false;
                }
                



                if(Email == ""){
                    document.getElementById("email").innerHTML="Please Enter Your Email";
                    return false;
                }
                if(Password == ""){
                    document.getElementById("password").innerHTML="please enter your password";
                    return false;
                }
                if(Password.length<8 ||Password.length>20){
                    document.getElementById("password").innerHTML="please enter more than 8 char";
                    return false;
                }


                if(ConformPass == ""){
                    document.getElementById("cpassword").innerHTML="Please conform password";
                    return false;
                }
                if(ConformPass !== Password ){
                    document.getElementById("cpassword").innerHTML="Please enter right password";
                    return false;
                }
            }
            


            

            
 
        